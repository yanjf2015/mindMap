#!/bin/bash
# Description: Add a New Redis Cluster!
# Author     : yuan.ran@msxf.com
# last modify date     : 2015.10.31 by yuan.ran
#
if [[ $1 == "" ]];then
        echo "Usage: $0 ***.msxf.lo port"
        exit 0
fi

REDIS=$1
PORT=$2
#ISNEW=$3      #0 代表新安装  1代表已安装过一个节点在同一个机器上

function OS_CONFIG ()
{
cat >> /etc/sysctl.conf <<EOF
vm.overcommit_memory = 1 
EOF

sysctl vm.overcommit_memory=1


echo never > /sys/kernel/mm/transparent_hugepage/enabled 
echo 1024 >/proc/sys/net/core/somaxconn
cat >> /etc/rc.local  <<EOF
echo never > /sys/kernel/mm/transparent_hugepage/enabled
echo 1024 >/proc/sys/net/core/somaxconn
EOF

cat >> /etc/security/limits.conf <<EOF
*     soft   nofile  65535
*     hard   nofile  65535
EOF

cat >> /etc/pam.d/login <<EOF
session required /lib/security/pam_limits.so
EOF


cat >> /home/finance/.bash_profile <<EOF
PATH=\$PATH:\$HOME/bin:/home/finance/App/${REDIS}/${PORT}/redis
export PATH
EOF

touch os_conf_ready
}

function BASE_WORKS ()
{

id finance >& /dev/null  
if [ $? -ne 0 ]  
then  
   useradd finance  
fi 

dirs=('/home/finance/App/' '/home/finance/Shell/' '/home/finance/Logs/' '/home/finance/Config/')
len=${#dirs[@]}
i=0
while [ $i -lt $len ]
do
	if [ ! -d ${dirs[$i]} ]
	then
		mkdir -p ${dirs[$i]}
	fi
	let i++
done
}

function NEW_BASE_WORKS ()
{
mkdir -p /home/finance/App/${REDIS}/${PORT}
mkdir -p /home/finance/Shell/${REDIS}/${PORT}
mkdir -p /home/finance/Logs/${REDIS}/${PORT}
mkdir -p /home/finance/App/${REDIS}/${PORT}/data
mkdir -p /home/finance/Config/${REDIS}/${PORT}
# /home/finance/Shell/${REDIS}/${PORT}
#chmod +x /home/finance/Shell/${DOMAIN}/tomcat 

}
############### SET TOMCAT SERVER ##################################
function REDIS_ADD ()
{
if [ ! -d redis-3.0.5 ]
then
	yum -y install gcc ruby ruby-rdoc rubygems  
	gem install redis --version 3.0.5
	tar xvf redis-3.0.5.gz >>/dev/null
fi
cd redis-3.0.5
make MALLOC=libc
cp -r src /home/finance/App/${REDIS}/${PORT}/redis
chown -R finance:finance /home/finance/Shell/
chown -R finance:finance /home/finance/App/
chown -R finance:finance /home/finance/Logs/
chown -R finance:finance /home/finance/Config/
echo "REDIS Config Complete...."
}


function REDIS_CONFIG ()
{
SH_FILE="/home/finance/Shell/${REDIS}/${PORT}/redis"
REDIS_BASE="/home/finance/App/${REDIS}/${PORT}/redis"

cat > /home/finance/Config/${REDIS}/${PORT}/redis.conf <<EOF
#GENERAL  
daemonize no  
tcp-backlog 511  
#requirepass MavXEFt0TtWi3llsboRObhVkfHUuc88Ontx
loglevel notice
logfile /home/finance/Logs/${REDIS}/${PORT}/redis.log
pidfile /home/finance/App/${REDIS}/${PORT}/data/redis.pid
timeout 0  
tcp-keepalive 0  
databases 16  
dir /home/finance/App/${REDIS}/${PORT}/data
slave-serve-stale-data yes  
#slave只读  
#masterauth MavXEFt0TtWi3llsboRObhVkfHUuc88Ontx
slave-read-only yes  
#not use default  
repl-disable-tcp-nodelay yes  
slave-priority 100  
#打开aof持久化  
appendonly no  
#每秒一次aof写  
appendfsync everysec  
#关闭在aof rewrite的时候对新的写操作进行fsync  
no-appendfsync-on-rewrite yes  
auto-aof-rewrite-min-size 64mb  
lua-time-limit 5000  
#打开redis集群  
cluster-enabled yes  
#节点互连超时的阀值  
cluster-node-timeout 15000  
cluster-migration-barrier 1  
slowlog-log-slower-than 10000  
slowlog-max-len 128  
notify-keyspace-events ""  
hash-max-ziplist-entries 512  
hash-max-ziplist-value 64  
list-max-ziplist-entries 512  
list-max-ziplist-value 64  
set-max-intset-entries 512  
zset-max-ziplist-entries 128  
zset-max-ziplist-value 64  
activerehashing yes  
client-output-buffer-limit normal 0 0 0  
client-output-buffer-limit slave 256mb 64mb 60  
client-output-buffer-limit pubsub 32mb 8mb 60  
hz 10  
aof-rewrite-incremental-fsync yes  

#监听tcp端口  
port ${PORT}
#最大可用内存  
maxmemory 1024m  
#内存耗尽时采用的淘汰策略:  
# volatile-lru -> remove the key with an expire set using an LRU algorithm  
# allkeys-lru -> remove any key accordingly to the LRU algorithm  
# volatile-random -> remove a random key with an expire set  
# allkeys-random -> remove a random key, any key  
# volatile-ttl -> remove the key with the nearest expire time (minor TTL)  
# noeviction -> don't expire at all, just return an error on write operations  
maxmemory-policy allkeys-lru  
#aof存储文件  
appendfilename "appendonly-${PORT}.aof"  
#rdb文件,只用于动态添加slave过程  
dbfilename dump-${PORT}.rdb  
#cluster配置文件(启动自动生成)  
cluster-config-file  /home/finance/Config/${REDIS}/${PORT}/cluster-nodes-${PORT}.conf  
#部署在同一机器的redis实例，把auto-aof-rewrite搓开，防止瞬间fork所有redis进程做rewrite,占用大量内存
auto-aof-rewrite-percentage 80-100 
EOF

cat  > $SH_FILE <<EOF
#!/bin/bash
# redis Settings
WHO=\$(whoami)
#########################starting#############
start() {
	echo "*****************************************"
	echo "***       redis starting action      ***"   
	echo "*****************************************"
	if [[ \$WHO == root ]];then
		su - finance -c	"$REDIS_BASE/redis-server /home/finance/Config/${REDIS}/${PORT}/redis.conf > /home/finance/Logs/${REDIS}/${PORT}/redis.log 2>&1 &"
	elif [[ \$WHO != finance ]];then
		su - finance -c	"$REDIS_BASE/redis-server /home/finance/Config/${REDIS}/${PORT}/redis.conf > /home/finance/Logs/${REDIS}/${PORT}/redis.log 2>&1 &"
		 
	fi
	if [[ \$? == 0 ]];then
        	echo "###########################"
        	echo "#redis started succeed!! #"
        	echo "###########################"
	fi
}

#########################stoping####################
stop() {
	echo "*****************************************"
	echo "***       redis stoping action       ***"
	echo "*****************************************"
        if [[ \$WHO == root ]];then
		su - finance -c "$REDIS_BASE/redis-cli -p ${PORT}  shutdown" 
	elif [[ \$WHO != finance ]];then
		su - finance -c "$REDIS_BASE/redis-cli -p ${PORT}  shutdown" 
	fi	

	if [[ \$? == 0 ]];then
        	echo "###########################"
        	echo "# redis stoped succeed!! #"
        	echo "###########################"
	fi
}


status() {
	echo "*****************************************"
	echo "***       redis status action       ***"
	echo "*****************************************"
        if [[ \$WHO == root ]];then
		su - finance -c "$REDIS_BASE/redis-cli -p ${PORT}   monitor" 
	elif [[ \$WHO != finance ]];then
		su - finance -c "$REDIS_BASE/redis-cli -p ${PORT}   monitor" 
	fi	

	if [[ \$? == 0 ]];then
        	echo "###########################"
        	echo "# redis status show!! #"
        	echo "###########################"
	fi
}


restart(){
        stop
        start
}

case \$1 in
  start)
        start
        ;;
  stop)
        stop
        ;;
  status)
        status
        ;;
  restart)
        restart
        ;;
  ?|help)
	echo $"Usage: 'redis' {start|status|stop|restart|help|?}"
        ;;
  *)
	echo $"Usage: 'redis' {start|status|stop|restart|help|?}"
esac
EOF



echo "Redis Config Complete...."


}


if [ ! -f os_conf_ready ];then
    OS_CONFIG
fi

if [ -d /home/finance/App/${redis}/${PORT} ];then
	echo -n "Project $1 exists !"
	 
else
    BASE_WORKS
	NEW_BASE_WORKS
	REDIS_ADD
	REDIS_CONFIG
	
fi




######################### END ##########################
#####change owner######
chown -R finance:finance /home/finance/{Logs,Config,App,Shell}
source /home/finance/.bash_profile
chmod +x /home/finance/Shell/${REDIS}/${PORT}/redis


echo "when all node add successed then create cluster like this
./redis-trib.rb create --replicas 1 x.x.x.x:7000 x.x.x.x:7001 x.x.x.x:7002 x.x.x.x:7003  x.x.x.x:7004  x.x.x.x:7005
"

#  修改gem sources  gem sources --add http://gems.ruby-china.org/  --remove https://rubygems.org/  查看：gem sources -l
#  下载redis安装包，启动redis服务
